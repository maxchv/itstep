# QueryingT-SQL
Demo and lab files for Querying with T-SQL course
